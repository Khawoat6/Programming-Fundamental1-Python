def is_perfect_number(n):
    i = 1
    s = 0
    if type(n) == int:
        while i < n:
            if (n % i) == 0:
                s += i
            i += 1
    if n == s:
        return True
    else:
        return False
