def use_all_aeiou(z):
    if 'a' in z and 'e' in z and 'i' in z and 'o' in z and 'u' in z:
        return True
    else:
        return False
