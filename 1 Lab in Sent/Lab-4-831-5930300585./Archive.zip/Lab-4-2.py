def binary_string(z):
    if z == 0:
        return '0'
    if z > 0:
        return ("{0:b}".format(z))
