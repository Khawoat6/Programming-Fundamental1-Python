print("Welcome to Change Calculator.")
x=input("Price: ")
xx=int(x)
y=input("Amount tendered: ")
yy=int(y)
z=yy-xx
q=input("change: "+str(z))
oat1=input("500: "+str(z//500))
o1=z%500
oat2=input("100: "+str(o1//100))
o2=o1%100
oat3=input("50: "+str(o2//50))
o3=o2%50
oat4=input("20: "+str(o3//20))
o4=o3%20
oat5=input("10: "+str(o4//10))
o5=o4%10
oat6=input("5: "+str(o5//5))
o6=o5%5
oat7=input("2: "+str(o6//2))
o7=o6%2
oat8=input("1: "+str(o7//1))
o8=o7%1
print("Thank you.")
