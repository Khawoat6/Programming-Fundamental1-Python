x=float(input("Enter the temperature in Calsius: "))
F=((9/5)*float(x)+32)
print("The temperature is",F,'degree Fahrenheit.')
